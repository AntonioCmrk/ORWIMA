package com.example.rushroyalehelper

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class StartScreen : Fragment() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {

        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {


        val view = inflater.inflate(R.layout.fragment_start_screen, container, false)
        /* view.findViewById<Button>(R.id.CardListButton).setOnClickListener {

             val  cardListFragment = CardList()
             val transaction: FragmentTransaction = FragmentManager().beginTransaction()
             transaction.replace(R.layout.fragment_start_screen, R.layout.fragment_card_list)
             transaction.commit()*/
        return view
    }


}

