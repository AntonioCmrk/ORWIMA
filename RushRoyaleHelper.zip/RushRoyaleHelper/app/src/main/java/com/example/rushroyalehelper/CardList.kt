package com.example.rushroyalehelper

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import java.util.*
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView


class CardList : Fragment() {



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val v = inflater.inflate(R.layout.fragment_card_list, container, false)
        val exampleList = generateDummyList(53)
        val cardListRecyclerView = v.findViewById<RecyclerView>(R.id.CardListRecyclerView)
        cardListRecyclerView.adapter = Adapter(exampleList)
        cardListRecyclerView.layoutManager = LinearLayoutManager(activity)
        cardListRecyclerView.setHasFixedSize(true)
        return v
    }

    private fun generateDummyList(size: Int): List<Item> {

        val list = ArrayList<Item>()

        for (i in 0 until size) {
            val drawable = when (i % 53) {
                0 -> R.drawable.archer_icon
                1 -> R.drawable.bombardier_icon
                2 -> R.drawable.cold_mage_icon
                3 -> R.drawable.fire_mage_icon
                4 -> R.drawable.hunter_icon
                5 -> R.drawable.lightning_mage_icon
                6 -> R.drawable.poisoner_icon
                7 -> R.drawable.bombardier_icon
                8 -> R.drawable.rogue_icon
                9 -> R.drawable.thrower_icon
                10 -> R.drawable.alchemist_icon
                10 -> R.drawable.banner_icon
                12 -> R.drawable.magic_cauldron_icon
                13 -> R.drawable.chemist_icon
                14 -> R.drawable.grindstone_icon
                15 -> R.drawable.priestess_icon
                16 -> R.drawable.sentry_icon
                17 -> R.drawable.sharpshooter_icon
                18 -> R.drawable.zealot_icon
                19 -> R.drawable.catapult_icon
                20 -> R.drawable.crystalmancer_icon
                21 -> R.drawable.engineer_icon
                22 -> R.drawable.gargoyle_icon
                23 -> R.drawable.executioner_icon
                24 -> R.drawable.mime_icon
                25 -> R.drawable.plague_doctor_icon
                26 -> R.drawable.ivy_icon
                27 -> R.drawable.portal_keeper_icon
                28 -> R.drawable.pyrotechnic_icon
                29 -> R.drawable.reaper_icon
                30 -> R.drawable.portal_keeper_icon
                31 -> R.drawable.thunderer_icon
                32 -> R.drawable.vampire_icon
                33 -> R.drawable.wind_archer_icon
                34 -> R.drawable.boreas_icon
                35 -> R.drawable.corsair_icon
                36 -> R.drawable.cultist_icon
                37 -> R.drawable.demon_hunter_icon
                38 -> R.drawable.demonologist_icon
                39 -> R.drawable.dryad_icon
                40 -> R.drawable.frost_icon
                41 -> R.drawable.harlequin_icon
                42 -> R.drawable.hex_icon
                43 -> R.drawable.knight_statue_icon
                44 -> R.drawable.clock_of_power_icon
                45 -> R.drawable.meteor_icon
                46 -> R.drawable.stasis_icon
                47 -> R.drawable.summoner_icon
                48 -> R.drawable.trapper_icon
                49 -> R.drawable.shaman_icon
                50 -> R.drawable.blade_dancer_icon
                51 -> R.drawable.inquisitor_icon
                52 -> R.drawable.robot_icon
                else -> R.drawable.scrapper_icon
            }

            val item = Item(drawable, "Item $i")
            list += item
        }

        return list
    }
}


