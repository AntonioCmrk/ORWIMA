package com.example.rushroyalehelper

data class Item(val imageResource: Int, val text: String)