package com.example.rushroyalehelper

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val startScreenFragment = CardList()
        val fm: FragmentManager = supportFragmentManager
        fm.beginTransaction().add(R.layout.fragment_card_list).commit()
        findViewById<Button>(R.id.CardListButton).setOnClickListener {

            val cardListFragment = CardList()
            val transaction: FragmentTransaction = FragmentManager().beginTransaction()
            transaction.replace(R.layout.activity_main, R.layout.fragment_card_list)
            transaction.commit()
        }
    }

}